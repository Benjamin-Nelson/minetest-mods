PLASMASCREEN
============

Mod adding a plasma screen TV for Minetest.

This mod adds a 2x3 plasma screen TV using a single large mesh node.

Point at the bottom center position where you want the TV to go, when placing.

Note:  If you're at a really steep view angle when trying to place a screen,
the mod may occasionally refuse to place it (or it just appears for a moment).
Just move over a bit, so that your target position is more directly in front
of you.

Code, textures and model are WTFPL.

