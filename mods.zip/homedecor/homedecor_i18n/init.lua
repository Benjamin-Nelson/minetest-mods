
-- This file intentionally left blank.

homedecor_i18n = { }

local MP = minetest.get_modpath(minetest.get_current_modname())
homedecor_i18n.gettext, homedecor_i18n.ngettext = dofile(MP.."/intllib.lua")
