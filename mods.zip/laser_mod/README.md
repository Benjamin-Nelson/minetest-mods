[mod] Laser Sword [0.4]
=======================

**depends:** default

**recommends:** 3d_armor (to see wielded weapons)


This mod adds laser swords to minetest. They are powerful and cut through anything but wear out somewhat quickly. Default textures are 32x32. 16x16 textures are also included.

**0.4 update by vitaminx**
  - bugfix for "undeclared global variable" error message

**0.3 update by vitaminx**
  - bugfix for server crash at player disconnect

**0.2 updates by sirken**
  - Recreated graphics
  - 16px and 32px textures
  - Added more swords
  - Added sword sounds
  - Changed recipes
  - Changed tool capabilities 

**0.1 initial release by pagliaccio**
