[mod] Laser Sword [0.2]
=======================

Code and graphics
CC BY-NC-SA 3.0 http://creativecommons.org/licenses/by-nc-sa/3.0/
- orginal by pagliaccio
- modified by sirken

Sounds
CC BY 3.0 http://creativecommons.org/licenses/by/3.0/
James Tubbrit (www.irishacts.com), FXHome.com Saber Sound
- modified by sirken
