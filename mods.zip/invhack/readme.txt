Licenses: CC0

See and or take items from players main inventory.
The invhack privilege requires to take items.

Tool: invhack:tool