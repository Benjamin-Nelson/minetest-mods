
# Intllib example

This is a simple mod showing how to use intllib.

It defines a test `intltest:test` item whose description is translated
according to the user's language.

Additionally, it demonstrates how to use plural forms by counting the
number of times the item has been used.
