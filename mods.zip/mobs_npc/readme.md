
NPC MOBS


NPC

- While NPC's don't actually spawn in the world just yet, they do have a spawn egg available to drop him/her into the world and wander around defending himself if attacked.  It will also he will help you attack any monsters in the area and will follow you if you hold a diamond. Right-clicking the NPC with a gold lump will make him drop steel tools or food, right-clicking with an empty hand orders the NPC to stay or follow if owned.

Trader

- Traders are new and still being tested but can be placed into the world using a spawn egg. Right-clicking on a trader opens his shop and allows you to buy his wares inside.  If provoked a trader will attack a player or monster.

Note: self.npc_drops and self.igor_drops are used for random item list when trading for gold and may be changed within the mob itself, if not found the global mobs.npc_drops and mobs.igor_drops are used instead for a default list.

Lucky Blocks: 4
