Technic chests
==============

License
-------

Copyright (C) 2012-2014 Maciej Kasatkin (RealBadAngel)

Technic chests code is licensed under the GNU LGPLv2+.

Texture licenses:

VanessaE: (WTFPL)
  * technic\_pencil\_icon.png
  * technic\_checkmark\_icon.png
  * technic\_chest\_overlay\_*.png
  * technic\_*\_chest\_lock\_overlay.png

sdzen (Elise Staudter) modified by VanessaE (CC BY-SA 3.0):
  * copper, iron, silver, gold, mithril chest textures 16x16
 
RealBadAngel: (WTFPL)
  * Everything else.

