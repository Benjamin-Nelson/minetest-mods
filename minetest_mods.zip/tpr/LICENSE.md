####DO WHAT YOU WANT TO PUBLIC LICENSE (DWYWPL)

December 2nd 2015
License Copyright (C) 2015 Michael Tomaino (PlatinumArts@gmail.com)
[www.sandboxgamemaker.com/DWYWPL/](www.sandboxgamemaker.com/DWYWPL/)

#####DO WHAT YOU WANT TO PUBLIC LICENSE
######TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

1. You are allowed to do whatever you want to with what content is using this license.
2. This content is provided 'as-is', without any express or implied warranty. In no event will the authors be held liable for any damages arising from the use of this content.
