# Super Diamonds Mod #

This MOD for Minetest adds Super diamond to the game. Super diamond is more stronger, durable and rare than regular diamond. You can craft awesome pick axe, axe or swords with it. Also it has a diamond apple what gives you super powers.

Completely revamped Diamond Mod. Now you can find "Super Diamond" in caves, which is also super rare :) all tools and weapons are fixed. Tools made from Super Diamond have enormous durability and they are strong comparable to Mithril (but not the same as Mithril), so the swords are cutting trough Mithril like trough a butter :) Also re-done all textures

![screenshot.png](https://bitbucket.org/repo/Lg9Xpa/images/1543365819-screenshot.png)